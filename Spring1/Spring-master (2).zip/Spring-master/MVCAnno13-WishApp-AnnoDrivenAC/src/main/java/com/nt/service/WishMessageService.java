package com.nt.service;

public interface WishMessageService {
	
	public   String  getWishMessage();

}
