package com.nt.dao;

import com.nt.bo.UserBO;

public interface LoginDAO {
    public  long  validate(UserBO bo);
}
