package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IocBoot81LmiApplicationTests {

	@Test
	void contextLoads() {
	}

}
