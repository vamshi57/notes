package com.nt.service;

import com.nt.dto.UserDTO;

public interface LoginMgmtService {
	public  String   authenticate(UserDTO dto);

}
