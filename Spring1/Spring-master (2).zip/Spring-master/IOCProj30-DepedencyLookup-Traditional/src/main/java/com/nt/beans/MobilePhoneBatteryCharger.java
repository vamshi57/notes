package com.nt.beans;

public class MobilePhoneBatteryCharger {
	
	public MobilePhoneBatteryCharger() {
		System.out.println("MobilePhoneBatteryCharger:: 0-param constructor");
	}
	
	
	public   void charging() {
		System.out.println("MobilePhoneBatteryCharger.charging()");
	}

}
