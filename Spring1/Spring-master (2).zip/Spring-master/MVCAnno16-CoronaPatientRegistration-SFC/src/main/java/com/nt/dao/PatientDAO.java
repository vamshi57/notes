package com.nt.dao;

import com.nt.bo.PatientBO;

public interface PatientDAO {
	public int insert(PatientBO bo);

}
