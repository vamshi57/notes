package com.nt.external;

public interface ExternalIccScoreComp {
	
	public String getScore(int mid);

}
