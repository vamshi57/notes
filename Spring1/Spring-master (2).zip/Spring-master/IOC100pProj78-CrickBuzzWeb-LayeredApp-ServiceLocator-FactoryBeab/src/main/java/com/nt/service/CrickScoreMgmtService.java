package com.nt.service;

import com.nt.external.ExternalIccScoreComp;

public interface CrickScoreMgmtService {
	public   String findScore(int mid) ;
	
}
